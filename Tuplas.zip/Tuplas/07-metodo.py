#Metodo de las tuplas

# index (): Encontrar la posición de un elemento .
 
tupla = ("a","b","c","c")

print(tupla.index("a"))

# count (): cuenta cuántas veces aparece un elemento en la tupla.

print(tupla.count ("c"))
