#Longitug en una tupla (len())

#Usar la función len () para determinar cuántos elementos 
#tiene una tupla.

tupla = (1,2,3,)
print(len (tupla))