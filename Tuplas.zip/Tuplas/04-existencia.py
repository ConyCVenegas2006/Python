#Verificar la existencia de un elemento (in):
#Saber usar el operador in para comprobar si un 
#elemento esta presente en una tupla

tupla = ( "python", "java", "C++")
print ("react" in tupla)