#Acceder a elementos por índice:

#Conocer que los elemntos en una
#tupla tienen índices que comienzan en 0

tupla = ("A", "B", "C")

print (tupla [0])
print (tupla [1])
print (tupla [2])
