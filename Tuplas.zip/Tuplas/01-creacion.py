#Creación de tupla
#Saber como definir una tupla utilizando perentesis ()
tupla = ("elemento1","elemento2", "elemento3")

print(tupla)