mi_lista = [12,33,34,44]
mi_lista [-1]= 8

print(mi_lista)