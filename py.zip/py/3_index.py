#lista.index(valor)

#crar una lista

mi_lista = [30,10,20,40]


# obtener el valor del indice}


indice = mi_lista.index(30)

print(indice)
