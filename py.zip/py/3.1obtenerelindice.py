# crear una lista

mi_lista = ["manzanas","platanos,","cerezas","tomates"]

print(mi_lista[1])
print(mi_lista[2])
print(mi_lista[3])