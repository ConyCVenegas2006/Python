# Constanza Concha
#17-03-2025


#1
lista_gatito = [ "Hitler", "Leo", "Blanca", "Tamy", "Pochita"]

print(lista_gatito[3])

#2

lista_gatito [-1] = "Conan  "

print(lista_gatito)

#3

lista_gatito.append("Naranjito")
print(lista_gatito)

#4
lista_gatito [2] = "Mandarina"

print(lista_gatito)

#5
lista_gatito.pop(3)
print(lista_gatito)

#6

indice = lista_gatito.index("Mandarina")

print(indice)

#7
lista_gatito.sort()

print(lista_gatito)

#8
lista_gatito.reverse()
print(lista_gatito)
