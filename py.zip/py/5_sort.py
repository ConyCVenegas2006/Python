mi_lista=[40, 50 ,60 ,10]

#ordnar de mayor a menor

mi_lista.sort()
print(mi_lista)