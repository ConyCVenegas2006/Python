


#list.append(valor)

#crar una lista

mi_lista = []

#añadir valores a la lista 

mi_lista.append(30)
mi_lista.append(20)
mi_lista.append(10)

print(mi_lista)