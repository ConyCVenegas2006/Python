mi_lista=[10,20,30,40]
mi_lista.reverse
print(reverse)